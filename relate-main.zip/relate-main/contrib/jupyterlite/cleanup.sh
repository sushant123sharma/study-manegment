#! /bin/bash

set -e

rm -Rf .cache env .jupyterlite.doit.db _output pack micromamba mamba-root files
