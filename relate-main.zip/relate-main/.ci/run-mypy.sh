#! /bin/bash

mypy relate course accounts prairietest
