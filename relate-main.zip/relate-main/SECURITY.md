# Security Policy

## Supported Versions

Only the `main` git branch can be expected to include fixes for security issues.

## Reporting a Vulnerability

Please email <inform@tiker.net> with security issues. You may use the GPG key with
fingerprint `71AA298BCA171145` to encrypt your communication.
